package com.example.workoutapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

//Imports for hardware sensors
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Date;




public class MainActivity extends AppCompatActivity {


//    private final int easySigShake = 5000000;
//    private final int mediumSigShake = 10000000;
//    private final int hardSigShake = 15000000;


//    private final int easySigShake = 1000000;
//    private final int mediumSigShake = 10000000;
//    private final int hardSigShake = 15000000;

    private final int easySigShake = 1000;
    private final int mediumSigShake = 2000;
    private final int hardSigShake = 3000;

    private double currentSigShake;
    private int mode; //indicator for what mode we are in.
    private final int easy = 1; //easy
    private final int medium = 2; //medium indicator for what mode we are in.
    private final int hard = 3; //hard indicator for what mode we are in.

    private final int easySong = 30;
    private final int mediumSong = 50;
    private final int hardSong = 60;
    private final int hardFlash = 20;

    private final int toSeconds = 1000;

    private ListView lvMenu;
    private Button btnStart;
    private Button btnStop;
    private TextView txtNumStep;
    private int stepCount;
    private final int finalStepCount = 100;
    private boolean started;
    private String onView;

//    Date currentTime;
//    Date prevTime;

    double currentTime;
    double prevTime;


    double startTime;
    double timeElapsed;

    //lecture variables.
    private CameraManager CamManager;
    private String CamID;
    private DecimalFormat df;

    //private float lastX, lastY, lastZ;  //old coordinate positions from accelerometer, needed to calculate delta.
    private float acceleration;
    private float currentAcceleration;
    private float lastAcceleration;

    MediaPlayer mp;
    final String[] Modes = {"Easy", "Medium", "Hard"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); //sets it to always be portrait

        //requesting camera stackoverflow
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) !=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CAMERA},
                    50); }


        lvMenu = (ListView) findViewById(R.id.lvMenu);
        btnStart = (Button) findViewById(R.id.btnStart);
        btnStop = (Button) findViewById(R.id.btnStop);
        txtNumStep = (TextView) findViewById(R.id.txtNumSteps);

        txtNumStep.setText("");
        currentSigShake = easySigShake; //always init at easy mode.
        mode = 1; //mode 1 is easyMode, mode2 is medium, mode 3 is hard
        stepCount = 0;//init step to be 0
        started = false; //init to be false

        currentTime = Calendar.getInstance().getTimeInMillis();
        prevTime = Calendar.getInstance().getTimeInMillis();

        //lecture
        CamManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            CamID = CamManager.getCameraIdList()[0];  //rear camera is at index 0
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }

        // initialize acceleration values
        acceleration = 0.00f;                                         //Initializing Acceleration data.
        currentAcceleration = SensorManager.GRAVITY_EARTH;            //We live on Earth.
        lastAcceleration = SensorManager.GRAVITY_EARTH;               //Ctrl-Click to see where else we could use our phone.


        //ArrayAdapter is the interface, the go between, between UI and Data
        ArrayAdapter ModeListAdapter = new ArrayAdapter<String>(MainActivity.this,           //Context
                android.R.layout.simple_list_item_1, //type of list (simple)
                Modes);                            //Data for the list

        lvMenu.setAdapter(ModeListAdapter);
        lvMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String theMode = String.valueOf(parent.getItemAtPosition(position));
                if (theMode.equals("Easy")) {
                    mode = easy;
                    currentSigShake = easySigShake;
                    Toast.makeText(getBaseContext(), "Easy Mode",Toast.LENGTH_SHORT).show();
                }
                else if (theMode.equals("Medium")) {
                    mode = medium;
                    currentSigShake = mediumSigShake;
                    Toast.makeText(getBaseContext(), "Medium Mode",Toast.LENGTH_SHORT).show();
                }
                else if (theMode.equals("Hard")) {
                    mode = hard;
                    currentSigShake = hardSigShake;
                    Toast.makeText(getBaseContext(), "Hard Mode",Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onStartWorkout();
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onStopWorkout();
            }
        });

    }
    @Override
    protected void onStart() {
        super.onStart();
        //enableAccelerometerListening();
    }
    @Override
    protected void onStop() {
        //disableAccelerometerListening();
        super.onStop();
    }


    //making a interface for sensor
    private final SensorEventListener sensorEventListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            prevTime = currentTime;
            currentTime = Calendar.getInstance().getTimeInMillis();
            //currentTime = Calendar.getInstance().getTimeInMillis();
            if (started) {
                float x = event.values[0];   //obtaining the latest sensor data.
                float y = event.values[1];
                float z = event.values[2];

                //currentTime = Calendar.getInstance().getTime();
                currentTime = Calendar.getInstance().getTimeInMillis();

                double deltaTime = currentTime - prevTime;


                //save prev value
                lastAcceleration = currentAcceleration;

                //calculate current acceleration
                //currentAcceleration = x * x + y * y + z * z;   //This is a simplified calculation, to be real we would need time and a square root.
                currentAcceleration = (x * x + y * y + z * z);
                currentAcceleration = (float) (Math.sqrt(currentAcceleration) /deltaTime);


                // calculate the change in acceleration        //Also simplified, but good enough to determine random shaking.
                acceleration = currentAcceleration *  (currentAcceleration - lastAcceleration);

                if (acceleration > currentSigShake) {
                    incrementStep();
                    if (stepCount == finalStepCount) {
                        onStopWorkout();
                    }
                    switch (mode) {
                        case easy:
                            //System.out.println(easy);
                            if (stepCount == easySong) {
                                //start super man song
                                mp = MediaPlayer.create(MainActivity.this, R.raw.supermantheme);
                                mp.start();
                            }
                            break;
                        case medium:
                            if (stepCount == mediumSong) {
                                //start starwars song
                                mp = MediaPlayer.create(MainActivity.this, R.raw.starwarstheme);
                                mp.start();
                            }
                            break;
                        case hard:
                            if (stepCount >= hardFlash) {
                                LightOn();
                            }
                            if (stepCount == hardSong) {
                                //start rocky 3 song
                                mp = MediaPlayer.create(MainActivity.this, R.raw.rocky3theme);
                                mp.start();
                            }
                            break;
                        default:
                            Toast.makeText(getBaseContext(), "No Mode",Toast.LENGTH_SHORT).show();
                    }
                }
                else
                LightOff();
            }

        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };


    // enable listening for accelerometer events
    private void enableAccelerometerListening() {
        // The Activity has a SensorManager Reference.
        // This is how we get the reference to the device's SensorManager.
        SensorManager sensorManager =
                (SensorManager) this.getSystemService(
                        Context.SENSOR_SERVICE);    //The last parm specifies the type of Sensor we want to monitor


        //Now that we have a Sensor Handle, let's start "listening" for movement (accelerometer).
        //3 parms, The Listener, Sensor Type (accelerometer), and Sampling Frequency.
        sensorManager.registerListener(sensorEventListener,
                sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_NORMAL);   //don't set this too high, otw you will kill user's battery.
    }

    // disable listening for accelerometer events
    private void disableAccelerometerListening() {

//Disabling Sensor Event Listener is two step process.
        //1. Retrieve SensorManager Reference from the activity.
        //2. call unregisterListener to stop listening for sensor events
        //THis will prevent interruptions of other Apps and save battery.

        // get the SensorManager
        SensorManager sensorManager =
                (SensorManager) this.getSystemService(
                        Context.SENSOR_SERVICE);

        // stop listening for accelerometer events
        sensorManager.unregisterListener(sensorEventListener,
                sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER));
    }


    public void LightOn() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            CameraManager camManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            try {
                CamID = camManager.getCameraIdList()[0];
                camManager.setTorchMode(CamID, true);
            } catch (CameraAccessException e) {
                e.printStackTrace();
            }
        }
//        try {
//            CamManager.setTorchMode(CamID, true);
//        } catch (CameraAccessException e) {
//            e.printStackTrace();
//        }

}

    public void LightOff() {
//        try {
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                CamManager.setTorchMode(CamID, false);
//            }
//        } catch (CameraAccessException e) {
//            e.printStackTrace();
//        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            CameraManager camManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            try {
                CamID = camManager.getCameraIdList()[0];
                camManager.setTorchMode(CamID, false);
            } catch (CameraAccessException e) {
                e.printStackTrace();
            }
        }
//        try {
//            CamManager.setTorchMode(CamID, false);
//        } catch (CameraAccessException e) {
//            e.printStackTrace();
//        }
    }



    public void incrementStep() {

        if (stepCount < finalStepCount ) {
            stepCount += 1;
            onView = String.valueOf(stepCount);
            txtNumStep.setText(onView);
        }
        else {
            disableAccelerometerListening();
        }
    }
    public void onStartWorkout() {
        stepCount = 0;
        started = true;
        onView = String.valueOf(stepCount);
        txtNumStep.setText(onView);
        currentTime = Calendar.getInstance().getTimeInMillis();
        startTime = Calendar.getInstance().getTimeInMillis();
        timeElapsed = 0;
        enableAccelerometerListening();
    }
    //stop everything, music etc.
    public void onStopWorkout() {
        switch (mode) {
            case easy:
                //System.out.println(easy);
                if (stepCount >= easySong) {
                    //stop super man song
                    mp.stop();
                }
                break;
            case medium:
                if (stepCount >= mediumSong) {
                    //stop starwars song
                    mp.stop();
                }
                break;
            case hard:
                if (stepCount >= hardSong) {
                    //stop starwars song
                    mp.stop();
                }
                break;
            default:
                mp.stop();
                Toast.makeText(getBaseContext(), "Ended",Toast.LENGTH_SHORT).show();
        }

        started = false;
        stepCount = 0;
        onView = "";
        txtNumStep.setText(onView); //make it default back to hint
        currentTime = Calendar.getInstance().getTimeInMillis();
        prevTime = Calendar.getInstance().getTimeInMillis();
        timeElapsed = currentTime - startTime;
        timeElapsed = timeElapsed/toSeconds; //Millis to seconds.
        LightOff();
        Toast.makeText(getBaseContext(), "Total time Elapsed: " + String.valueOf(timeElapsed) + " seconds", Toast.LENGTH_SHORT).show();
        disableAccelerometerListening();
    }


}