package com.example.mymp3basic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    private static final int MY_PERMISSION_REQUEST = 1;
    ArrayList<String> arrayList;
    ListView listView;
    ArrayAdapter<String> adapter;
    MediaPlayer mp;

    // Storage Permissions
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //add init playlists.

        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                    Manifest.permission.READ_EXTERNAL_STORAGE)) {
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, MY_PERMISSION_REQUEST);
            } else {
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, MY_PERMISSION_REQUEST);
            }
        }

        else {
            verifyStoragePermissions(this);
            doStuff();
        }
    }
    /**
     * Checks if the app has permission to write to device storage
     *
     * If the app does not has permission then the user will be prompted to grant permissions
     *
     * @param activity
     */
    public static void verifyStoragePermissions(Activity activity) {
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }

    public void doStuff() {
        listView = (ListView) findViewById(R.id.listView);
        arrayList = new ArrayList<>();
        getMusic();
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, arrayList);
        listView.setAdapter(adapter);

        mp = new MediaPlayer();
//        mp.setAudioAttributes(
//                new AudioAttributes.Builder()
//                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
//                        .setUsage(AudioAttributes.USAGE_MEDIA)
//                        .build()
//        );

        mp.setAudioStreamType(AudioManager.STREAM_MUSIC);


        String mFileName = Environment.getExternalStorageDirectory().getAbsolutePath();
//        String aSong = mFileName + "/Music/Bios.mp3";
//        try {
//            Toast.makeText(getBaseContext(), aSong, Toast.LENGTH_SHORT).show();
//            mp.setDataSource(aSong);
//            mp.prepare();
//            mp.start();
//            Toast.makeText(getBaseContext(), aSong, Toast.LENGTH_SHORT).show();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String theClick = String.valueOf(parent.getItemAtPosition(position));
                String[] splitted = theClick.split("\n", 2);
                String loc = splitted[1];
                Uri locs = Uri.parse(loc);
                //String mFileName = Environment.getExternalStorageDirectory().getAbsolutePath();


//                ContentResolver contentResolver = getContentResolver();
//                Uri songUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
//                Cursor songCursor = contentResolver.query(songUri, null, null, null, null);
//                songCursor.moveToPosition(position);
//                String thestr = songCursor.toString();
//
//                String strUri = songUri.toString();

                //String combinedUri = strUri + loc;
                //locs = Uri.parse(combinedUri);

                Toast.makeText(getBaseContext(), loc, Toast.LENGTH_SHORT).show();
                Toast.makeText(getBaseContext(), mFileName, Toast.LENGTH_SHORT).show();
                //Toast.makeText(getBaseContext(), strUri, Toast.LENGTH_SHORT).show();
                //Toast.makeText(getBaseContext(), thestr, Toast.LENGTH_SHORT).show();

                try {
                    //mp.stop();
                    //mp.setDataSource(getApplicationContext(), locs);
                    //mp.setDataSource(getApplicationContext(), locs);
                    mp.setDataSource(loc);
                    mp.prepare();
                    //mp.setDataSource(loc);
                    //mp.prepare(); // might take long! (for buffering, etc)
                    //mp.prepareAsync();
                    mp.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });
    }

    public void getMusic() {
        ContentResolver contentResolver = getContentResolver();
        Uri songUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor songCursor = contentResolver.query(songUri, null, null, null, null);

        if (songCursor != null && songCursor.moveToFirst()) {
            int songTitle = songCursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
            int songArtist = songCursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
            int songLocation = songCursor.getColumnIndex(MediaStore.Audio.Media.DATA);

            do {

                String currentTitle = songCursor.getString(songTitle);
                String currentArtist = songCursor.getString(songArtist);
                String currentLocation = songCursor.getString(songLocation);

//                arrayList.add("Title: " + currentTitle + "\n"
//                        + "Artist: " + currentArtist + "\n"
//                        + "Location" + currentLocation
//                );

//                arrayList.add(
//                        currentTitle + "\n"
//                        + currentArtist + "\n"
//                        + currentLocation + "\n"
//                );
                arrayList.add(
                        currentTitle + "\n"
                                + currentLocation
                );
                //arrayList.add(currentTitle + "\n" + currentArtist);
            } while (songCursor.moveToNext());

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSION_REQUEST: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ContextCompat.checkSelfPermission(MainActivity.this,
                            Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show();

                    }
                } else {
                    Toast.makeText(this, "Permission not granted", Toast.LENGTH_SHORT).show();
                    finish();
                }
                return;
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}