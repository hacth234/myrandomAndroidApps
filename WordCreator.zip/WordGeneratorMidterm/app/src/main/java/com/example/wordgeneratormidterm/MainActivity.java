package com.example.wordgeneratormidterm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {


    private int currentPoints = 0;
    private Button btnOne;
    private Button btnTwo;
    private Button btnThree;
    private Button btnFour;
    private Button btnFive;
    private Button btnSix;
    private Button btnSeven;
    private Button btnStart;
    private Button btnEnd;
    private Button btnSubmit;



    private final int totalButtons = 7;

    private char[] theWordBuild;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        btnOne = (Button) findViewById(R.id.btnOne);
        btnTwo = (Button) findViewById(R.id.btnTwo);
        btnThree = (Button) findViewById(R.id.btnThree);
        btnFour = (Button) findViewById(R.id.btnFour);
        btnFive = (Button) findViewById(R.id.btnFive);
        btnSix = (Button) findViewById(R.id.btnSix);
        btnSeven = (Button) findViewById(R.id.btnSeven);

        btnStart = (Button) findViewById(R.id.btnStart);
        btnEnd = (Button) findViewById(R.id.btnEnd);
        btnSubmit = (Button) findViewById(R.id.btnSubmit);

        theWordBuild = new char[totalButtons]; //will be what shows

        btnStart.setEnabled(true);
        btnEnd.setEnabled(false);

        btnOne.setEnabled(false);//init no game start yet
        btnTwo.setEnabled(false);
        btnThree.setEnabled(false);
        btnFour.setEnabled(false);
        btnFive.setEnabled(false);
        btnSix.setEnabled(false);
        btnSeven.setEnabled(false);
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameReset();
            }
        });

        btnEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameEnd();
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toastIt();
            }
        });

        btnOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String theLetter = btnOne.getText().toString();
                buttonClicked(theLetter.charAt(0));
                btnOne.setEnabled(false);
            }
        });

        btnTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String theLetter = btnTwo.getText().toString();
                buttonClicked(theLetter.charAt(0));
                btnTwo.setEnabled(false);
            }
        });

        btnThree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String theLetter = btnThree.getText().toString();
                buttonClicked(theLetter.charAt(0));
                btnThree.setEnabled(false);
            }
        });

        btnFour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String theLetter = btnFour.getText().toString();
                buttonClicked(theLetter.charAt(0));
                btnFour.setEnabled(false);
            }
        });

        btnFive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String theLetter = btnFive.getText().toString();
                buttonClicked(theLetter.charAt(0));
                btnFive.setEnabled(false);
            }
        });

        btnSix.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String theLetter = btnSix.getText().toString();
                buttonClicked(theLetter.charAt(0));
                btnSix.setEnabled(false);
            }
        });

        btnSeven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String theLetter = btnSeven.getText().toString();
                buttonClicked(theLetter.charAt(0));
                btnSeven.setEnabled(false);
            }
        });
    }


    public void gameReset() {
        //make random words by calling setText for each one to Seven button
        btnStart.setEnabled(false);
        btnEnd.setEnabled(true);
        currentPoints = 0;

        Random rnd = new Random();
        for (int i = 0; i < totalButtons; i++ ){
            char c = (char) ('A' + rnd.nextInt(26));
            if(i == 0) {
                btnOne.setText(String.valueOf(c));
            }
            else if (i == 1) {
                btnTwo.setText(String.valueOf(c));
            }
            else if (i == 2) {
                btnThree.setText(String.valueOf(c));
            }
            else if (i == 3) {
                btnFour.setText(String.valueOf(c));
            }
            else if (i == 4) {
                btnFive.setText(String.valueOf(c));
            }
            else if (i == 5) {
                btnSix.setText(String.valueOf(c));
            }
            else if (i == 6) {
                btnSeven.setText(String.valueOf(c));
            }
        }

        btnOne.setEnabled(true);
        btnTwo.setEnabled(true);
        btnThree.setEnabled(true);
        btnFour.setEnabled(true);
        btnFive.setEnabled(true);
        btnSix.setEnabled(true);
        btnSeven.setEnabled(true);
    }

    public void gameEnd() {
        //reset back to init state

        currentPoints = 0;
        btnEnd.setEnabled(false);
        btnStart.setEnabled(true);

        btnOne.setEnabled(false);
        btnTwo.setEnabled(false);
        btnThree.setEnabled(false);
        btnFour.setEnabled(false);
        btnFive.setEnabled(false);
        btnSix.setEnabled(false);
        btnSeven.setEnabled(false);

        btnOne.setText("");
        btnTwo.setText("");
        btnThree.setText("");
        btnFour.setText("");
        btnFive.setText("");
        btnSix.setText("");
        btnSeven.setText("");

        theWordBuild = new char[totalButtons];
    }

    public void buttonClicked(char ch) {
        //takes a char ch increment.
        theWordBuild[currentPoints] = ch;
        currentPoints += 1;
    }

    public void toastIt() {
        String toToast = "";
        for (int i = 0; i < theWordBuild.length; i++) {
            toToast += String.valueOf(theWordBuild[i]); //string build it
        }

        String toShow = "Your word is ";
        toShow += toToast;
        toShow = toShow + ", points = " + String.valueOf(currentPoints);
        Toast.makeText(this, toShow, Toast.LENGTH_SHORT).show();
    }
}